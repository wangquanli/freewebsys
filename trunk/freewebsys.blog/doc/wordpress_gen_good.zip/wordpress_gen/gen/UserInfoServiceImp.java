package com.freewebsys.blog.service.impl;

import java.util.List;
import java.util.Map;
import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.freewebsys.blog.dao.BaseDao;
import com.freewebsys.blog.page.PageConf;
import com.freewebsys.blog.pojo.UserInfo;
import com.freewebsys.blog.service.UserInfoService;
 
public class UserInfoServiceImp implements UserInfoService {
	
	@Autowired
	private BaseDao baseDao;

	private static Log log = LogFactory.getLog(UserInfoServiceImp.class);

	/**
	 * UserInfo删除
	 */
	@Transactional
	public void deleteUserInfoById(Long id) throws Exception {
		log.info("deleteUserInfoById：" + id);
		try{
			UserInfo userInfo = (UserInfo) baseDao.findById(UserInfo.class, id);
			baseDao.delete(userInfo);
		} catch (Exception e) {
			log.info("UserInfo删除异常");
			e.printStackTrace();
		}
	}

	/**
	 * UserInfo保存
	 */
	@Transactional
	public void saveUserInfo(UserInfo userInfo) throws Exception {
		log.info("saveUserInfo：" + userInfo);
		try {
			baseDao.save(userInfo);
		} catch (Exception e) {
			log.info("UserInfo保存异常");
			e.printStackTrace();
		}
	}

	/**
	 * UserInfo按ID查询
	 */
	@Transactional
	public UserInfo findUserInfoById(Long id) throws Exception {
		log.info("findUserInfoById：" + id);
		try {
			return (UserInfo) baseDao.findById(UserInfo.class, id);
		} catch (Exception e) {
			log.info("UserInfo按ID查询异常");
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * UserInfo分页
	 */
	@Transactional
	public PageConf findUserInfoPageList(int start, int limit, Map map) throws Exception {
		log.info("findUserInfoPageList：" + start + "," + limit);
		try {
			String hql = " select module from UserInfo module ";
			return baseDao.findPage(start, limit, hql);
		} catch (Exception e) {
			log.info("UserInfo分页异常");
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 查询UserInfo全部
	 */
	@Transactional
	public List<UserInfo> findAllUserInfo(Map map) throws Exception {
		log.info("findAllUserInfo：");
		try {
			String hql = " select module from UserInfo module ";
			return baseDao.find(hql);
		} catch (Exception e) {
			log.info("查询UserInfo全部异常");
			e.printStackTrace();
		}
		return null;
	}

}
